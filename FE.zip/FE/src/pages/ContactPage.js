import React from 'react';
import './ContactPage.css';

const ContactPage = () => {
  return (
    <div className="contact-page">
      <h1>Contact Us</h1>
      <p>For inquiries, please reach out to us:</p>
      <h2>+91 9370403372</h2>
      <h2>umangbhardwaj855@gmail.com</h2>
    </div>
  );
};

export default ContactPage;
