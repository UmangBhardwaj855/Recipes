import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchRecipeById } from '../api/api'; // API function to fetch recipe details
import imageMapping from '../utils/imageMapping'; // Mapping for images
import './RecipeDetailsPage.css'; // Styles for the page

const RecipeDetailsPage = () => {
  const { id } = useParams(); // Extract the recipe ID from the URL
  const [recipe, setRecipe] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await fetchRecipeById(id); // Fetch recipe details by ID
        if (data) {
          setRecipe(data);
        } else {
          setError('Recipe not found.');
        }
      } catch (err) {
        console.error('Error fetching recipe details:', err);
        setError('Failed to fetch recipe details.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;
  if (!recipe) return <p>Recipe details are not available.</p>;

  // Get recipe image from mapping or use a default image
  const formattedName = recipe.name
    ? recipe.name.toLowerCase().replace(/ /g, '-').replace(/[()]/g, '')
    : 'default';
  const recipeImage = imageMapping[formattedName] || '/images/recipes/default.jpg';

  return (
    <div className="recipe-details">
      <h1>{recipe.name}</h1>
      <img src={recipeImage} alt={recipe.name} className="details-image" />
      <h2>Instructions:</h2>
      <p>{recipe.instructions || 'No instructions available for this recipe.'}</p>
      <h2>Ingredients:</h2>
      <ul>
        {recipe.ingredients && recipe.ingredients.length > 0 ? (
          recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))
        ) : (
          <p>No ingredients available for this recipe.</p>
        )}
      </ul>
    </div>
  );
};

export default RecipeDetailsPage;
