import React from 'react';
import './AboutPage.css';

const AboutPage = () => {
  return (
    <div className="about-page">
      <h1>About Our Recipes</h1>
      <p>
        Welcome to the Umang's Recipes app! Here, you’ll find a variety of recipes
        from all over the world. Whether you’re in the mood for classic Italian
        pasta, spicy Indian curries, or refreshing smoothies, we have something for everyone!
      </p>
      <img
        src="/images/recipes/about-recipes.jpg"
        alt="Delicious recipes"
        className="about-image"
      />
    </div>
  );
};

export default AboutPage;
