import React, { useEffect, useState } from 'react';
import { fetchAllRecipes, fetchRecipesByCuisine } from '../api/api';
import RecipeGrid from '../components/Grid/RecipeGrid';


const HomePage = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCuisine, setSelectedCuisine] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = selectedCuisine
          ? await fetchRecipesByCuisine(selectedCuisine)
          : await fetchAllRecipes();
        setRecipes(data);
      } catch (error) {
        console.error('Error fetching recipes:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [selectedCuisine]);

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>Discover Delicious Recipes</h1>
      <div style={{ marginBottom: '20px' }}>
        <select
          onChange={(e) => setSelectedCuisine(e.target.value)}
          value={selectedCuisine}
          style={{
            padding: '10px',
            fontSize: '16px',
            borderRadius: '5px',
            border: '1px solid #c74021',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            backgroundColor: '#fff',
          }}
        >
          <option value="">All Cuisines</option>
          <option value="Italian">Italian</option>
          <option value="Asian">Asian</option>
          <option value="American">American</option>
          <option value="Mexican">Mexican</option>
          <option value="Mediterranean">Mediterranean</option>
          <option value="Pakistani">Pakistani</option>
          <option value="Japanese">Japanese</option>
          <option value="Moroccan">Moroccan</option>
          <option value="Korean">Korean</option>
          <option value="Greek">Greek</option>
          <option value="Thai">Thai</option>
          <option value="Indian">Indian</option>
          <option value="Turkish">Turkish</option>
          <option value="Smoothie">Smoothie</option>
          <option value="Russian">Russian</option>
          <option value="Lebanese">Lebanese</option>
          <option value="Brazilian">Brazilian</option>
        </select>
      </div>
      {loading ? (
        <p style={{ fontSize: '18px', fontWeight: 'bold', color: '#c74021' }}>Loading...</p>
      ) : (
        <RecipeGrid recipes={recipes} />
      )}
    </div>
  );
};

export default HomePage;
