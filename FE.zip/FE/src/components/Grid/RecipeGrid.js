
import React from 'react';
import RecipeCard from '../Card/RecipeCard';
import './RecipeGrid.css'; // Assuming you have a CSS file for styling

const RecipeGrid = ({ recipes }) => {
  if (!recipes || recipes.length === 0) {
    return <p>No recipes available.</p>;
  }

  return (
    <div className="recipe-grid">
      {recipes.map((recipe) => (
        <RecipeCard key={recipe.id} recipe={recipe} />
      ))}
    </div>
  );
};

export default RecipeGrid;
