import React, { useState } from 'react';
import './RecipeCard.css';
import Modal from '../Modal/Modal';
import imageMapping from '../../utils/imageMapping';

const RecipeCard = ({ recipe }) => {
  const [showModal, setShowModal] = useState(false);

  if (!recipe) {
    return null;
  }

  const {
    id,
    title = 'Unknown Recipe',
    cuisine = 'Unknown Cuisine',
    caloriesPerServing,
    instructions,
  } = recipe;

  const formattedTitle = title.replace(/ /g, '-').toLowerCase();
  const imagePath = imageMapping[formattedTitle] || '/images/recipes/default.jpg';

  const handleShowMoreClick = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div className="recipe-card" key={id}>
      <div className="recipe-image-container">
        <img
          src={imagePath}
          alt={title}
          className="recipe-image"
          onError={(e) => {
            e.target.onerror = null;
            e.target.src = '/images/recipes/default.jpg';
          }}
        />
      </div>
      <div className="recipe-details">
        <h3 className="recipe-title">{title}</h3>
        <p className="recipe-cuisine">Cuisine: {cuisine.toLowerCase()}</p>
        <p className="recipe-calories">Calories: {caloriesPerServing || 'N/A'}</p>
        <p className="recipe-instructions">
          Instructions: {instructions ? `${instructions.substring(0, 100)}...` : 'No instructions available'}
        </p>
        {instructions && (
          <div className="show-more-button-container">
            <button className="show-more-button" onClick={handleShowMoreClick}>
              Show More
            </button>
          </div>
        )}
      </div>
      <Modal show={showModal} onClose={handleCloseModal} content={instructions} />
    </div>
  );
};

export default RecipeCard;
