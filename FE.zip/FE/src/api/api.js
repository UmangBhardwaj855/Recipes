import axios from 'axios';

// Base API URL
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080';

// Fetch all recipes
export const fetchAllRecipes = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/recipes`);
    return response.data;
  } catch (error) {
    console.error('Error fetching all recipes:', error);
    throw new Error('Failed to fetch recipes. Please try again later.');
  }
};

// Fetch recipes by cuisine
export const fetchRecipesByCuisine = async (cuisine) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/recipes/cuisine/${cuisine}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching recipes by cuisine:', error);
    throw new Error('Failed to fetch recipes. Please try again later.');
  }
};

// Fetch recipe by ID
export const fetchRecipeById = async (id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/recipes/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching recipe by ID:', error);
    throw new Error('Failed to fetch the recipe. Please try again later.');
  }
};
