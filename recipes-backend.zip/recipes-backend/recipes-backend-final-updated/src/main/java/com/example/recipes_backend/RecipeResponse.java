
package com.example.recipes_backend;

import java.util.List;

public class RecipeResponse {
    private List<RecipeDTO> recipes;

    // Getters and Setters
    public List<RecipeDTO> getRecipes() {
        return recipes;
    }

    public void setRecipes(List<RecipeDTO> recipes) {
        this.recipes = recipes;
    }
}
