
package com.example.recipes_backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/recipes")
@CrossOrigin(origins = "http://localhost:3000")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;
    
    @GetMapping("/load")
    public String loadRecipes() {
        recipeService.loadData();
        return "Recipes loaded into the in-memory database!";
    }

    // Endpoint to get all recipes
    @GetMapping
    public List<Recipe> getAllRecipes() {
        return recipeService.getAllRecipes();
    }

    // Endpoint to get recipes by cuisine
    @GetMapping("/cuisine/{cuisine}")
    public List<Recipe> getRecipesByCuisine(@PathVariable String cuisine) {
        return recipeService.getRecipesByCuisine(cuisine);
    }

    // Endpoint to get a recipe by ID
    @GetMapping("/{id}")
    public Recipe getRecipeById(@PathVariable Long id) {
        return recipeService.getRecipeById(id);
    }

    // Endpoint to sort recipes by calories
    @GetMapping("/sort/calories")
    public List<Recipe> getRecipesSortedByCalories(@RequestParam(defaultValue = "true") boolean ascending) {
        return recipeService.getRecipesSortedByCalories(ascending);
    }
}
