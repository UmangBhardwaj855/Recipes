
package com.example.recipes_backend;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Recipe {
    @Id
    private Long id;
    private String title;
    private String cuisine;
    private int caloriesPerServing;
    
    @Column(length = 1000)
    private String instructions;
    
    // Constructors
    public Recipe() {
    }

    public Recipe(Long id, String title, String cuisine, int caloriesPerServing, String instructions) {
        this.id = id;
        this.title = title;
        this.cuisine = cuisine;
        this.caloriesPerServing = caloriesPerServing;
        this.instructions = instructions;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }

    public int getCaloriesPerServing() {
        return caloriesPerServing;
    }

    public void setCaloriesPerServing(int caloriesPerServing) {
        this.caloriesPerServing = caloriesPerServing;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }
}
