
package com.example.recipes_backend;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecipeService {

    private final RecipeRepository recipeRepository;
    private final RestTemplate restTemplate;

    public RecipeService(RecipeRepository recipeRepository) {
        this.recipeRepository = recipeRepository;
        this.restTemplate = new RestTemplate();
    }

    // Fetch data from the API and load into the database
    @PostConstruct
    public void loadData() {
        String apiUrl = "https://dummyjson.com/recipes";
        RecipeResponse response = restTemplate.getForObject(apiUrl, RecipeResponse.class);

        if (response != null && response.getRecipes() != null) {
            response.getRecipes().forEach(dto -> {
                Recipe recipe = new Recipe();
                recipe.setId(dto.getId());
                recipe.setTitle(dto.getTitle());
                recipe.setCuisine(dto.getCuisine());
                recipe.setCaloriesPerServing(dto.getCaloriesPerServing());
                // Convert list of instructions to a single string
                recipe.setInstructions(String.join(" ", dto.getInstructions()));
                recipeRepository.save(recipe);
            });
        }
    }


    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }

    public List<Recipe> getRecipesByCuisine(String cuisine) {
        return recipeRepository.findAll()
                .stream()
                .filter(recipe -> recipe.getCuisine().equalsIgnoreCase(cuisine))
                .toList();
    }

    public Recipe getRecipeById(Long id) {
        return recipeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recipe not found with ID: " + id));
    }

    public List<Recipe> getRecipesSortedByCalories(boolean ascending) {
        return recipeRepository.findAll()
                .stream()
                .sorted(ascending
                        ? Comparator.comparingInt(Recipe::getCaloriesPerServing)
                        : Comparator.comparingInt(Recipe::getCaloriesPerServing).reversed())
                .toList();
    }
}
